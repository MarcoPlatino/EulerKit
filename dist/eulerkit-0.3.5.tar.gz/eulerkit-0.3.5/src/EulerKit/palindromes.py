def palindrome(a):
    if str(a) == str(a)[::-1]:
        return True
    return False
        